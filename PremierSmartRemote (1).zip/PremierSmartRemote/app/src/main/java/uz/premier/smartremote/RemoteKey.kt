package uz.premier.smartremote

/** Пультдаги барча тугмалар. Телевизорга юбориш кейинги босқичда уланади. */
enum class RemoteKey {
    POWER, MENU, MUTE,
    UP, DOWN, LEFT, RIGHT, OK,
    BACK, EXIT, HOME, AIR_MOUSE,
    NETFLIX, YOUTUBE, ITV, SOURCE,
    VOL_DOWN, VOL_UP, VOICE
}

/** Телевизорга улаш усуллари. */
enum class ConnectionMethod { WIFI, BLUETOOTH }
