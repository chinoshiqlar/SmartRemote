package uz.premier.smartremote

import android.content.Context
import android.hardware.ConsumerIrManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * ИК орқали NEC буйруқ юбориш (38 кГц). Ҳозирча фақат Power учун:
 * тўғри код топилгач телефонда сақланади.
 * ДИҚҚАТ: ТВнинг ҳақиқий коди номаълум, шунинг учун уни излаш режими бор.
 */
class IrRemote(context: Context) {

    private val app = context.applicationContext
    private val ir = app.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
    private val prefs = app.getSharedPreferences("ir", Context.MODE_PRIVATE)

    val available: Boolean
        get() = try { ir?.hasIrEmitter() == true } catch (_: Exception) { false }

    var address by mutableStateOf(prefs.getInt("addr", -1))
        private set
    var command by mutableStateOf(prefs.getInt("cmd", -1))
        private set

    val hasSaved: Boolean get() = address >= 0 && command >= 0

    private fun loadLearned(): Map<String, Int> = RemoteKey.values().mapNotNull { k ->
        val v = prefs.getInt("k_${k.name}", -1)
        if (v >= 0) k.name to v else null
    }.toMap()

    /** Ўрганилган тугмалар: тугма номи -> ИК буйруқ (манзил Power билан бир хил). */
    var learned by mutableStateOf(loadLearned())
        private set

    fun saveKey(key: RemoteKey, cmd: Int) {
        prefs.edit().putInt("k_${key.name}", cmd).apply()
        learned = loadLearned()
    }

    fun clearKeys() {
        val e = prefs.edit()
        RemoteKey.values().forEach { e.remove("k_${it.name}") }
        e.apply()
        learned = emptyMap()
    }

    /** true — ИК орқали юборилди; false — бу тугма учун код йўқ. */
    fun sendKey(key: RemoteKey): Boolean {
        if (key == RemoteKey.POWER) return sendPower()
        if (address < 0) return false
        val c = learned[key.name] ?: return false
        return send(address, c)
    }

    fun send(addr: Int, cmd: Int): Boolean {
        val e = ir ?: return false
        return try {
            e.transmit(38_000, pattern(addr, cmd))
            true
        } catch (_: Exception) {
            false
        }
    }

    fun sendPower(): Boolean = hasSaved && send(address, command)

    fun save(addr: Int, cmd: Int) {
        prefs.edit().putInt("addr", addr).putInt("cmd", cmd).apply()
        address = addr
        command = cmd
    }

    fun clear() {
        prefs.edit().remove("addr").remove("cmd").apply()
        address = -1
        command = -1
        clearKeys()
    }

    /** NEC: 9мс+4.5мс старт, 32 бит (адрес, ~адрес, буйруқ, ~буйруқ), LSB биринчи, стоп бит. */
    private fun pattern(addr: Int, cmd: Int): IntArray {
        val data = (addr and 0xFF) or
            ((addr.inv() and 0xFF) shl 8) or
            ((cmd and 0xFF) shl 16) or
            ((cmd.inv() and 0xFF) shl 24)
        val p = ArrayList<Int>(68)
        p += 9000; p += 4500
        for (i in 0 until 32) {
            p += 560
            p += if ((data shr i) and 1 == 1) 1690 else 560
        }
        p += 560
        return p.toIntArray()
    }

    companion object {
        /** Хитой плата ТВларида кўп учрайдиган NEC манзиллари (аниқ эмас, шунинг учун излаймиз). */
        val CANDIDATE_ADDRESSES = intArrayOf(
            0x00, 0x40, 0x04, 0x01, 0x02, 0x08, 0x10, 0x20, 0x80,
            0x07, 0x0E, 0x18, 0x1C, 0x30, 0x50, 0x60, 0x70, 0x78
        )
    }
}
