package uz.premier.smartremote.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.SettingsRemote
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.premier.smartremote.BluetoothRemote
import uz.premier.smartremote.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConnectionSheet(
    bt: BluetoothRemote,
    onStartBluetooth: () -> Unit,
    onMakeVisible: () -> Unit,
    onOpenBtSettings: () -> Unit,
    onOpenIr: () -> Unit,
    onOpenIrLearn: () -> Unit,
    onOpenWifiCheck: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF161616),
        contentColor = Color(0xFFEDEDED)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 16.dp)
        ) {
            Text(stringResource(R.string.sheet_title), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(stringResource(R.string.sheet_subtitle), fontSize = 14.sp, color = TextMuted)
            Spacer(Modifier.height(16.dp))

            // Bluetooth
            MethodCard(
                icon = Icons.Default.Bluetooth,
                title = stringResource(R.string.bluetooth_title),
                badge = stringResource(R.string.badge_experimental),
                description = stringResource(R.string.bluetooth_desc)
            ) {
                Spacer(Modifier.height(12.dp))
                Text(stringResource(R.string.bt_step1), fontSize = 13.sp, color = TextMuted, lineHeight = 18.sp)
                Spacer(Modifier.height(6.dp))
                Text(stringResource(R.string.bt_step2), fontSize = 13.sp, color = TextMuted, lineHeight = 18.sp)
                Spacer(Modifier.height(6.dp))
                Text(stringResource(R.string.bt_step3), fontSize = 13.sp, color = TextMuted, lineHeight = 18.sp)
                Spacer(Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            onStartBluetooth()
                            onMakeVisible()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = KeyFace, contentColor = KeyIcon)
                    ) { Text(stringResource(R.string.bt_visible), fontSize = 13.sp) }
                    OutlinedButton(onClick = onOpenBtSettings) {
                        Text(stringResource(R.string.bt_settings), fontSize = 13.sp)
                    }
                }

                Spacer(Modifier.height(16.dp))
                Text(stringResource(R.string.bt_paired_title), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                if (bt.bonded.isEmpty()) {
                    Text(stringResource(R.string.bt_paired_empty), fontSize = 13.sp, color = TextMuted)
                } else {
                    bt.bonded.forEach { dev ->
                        val connected = bt.state == BluetoothRemote.State.CONNECTED && bt.hostName == dev.name
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    onStartBluetooth()
                                    if (connected) bt.disconnect() else bt.connect(dev.address)
                                }
                                .padding(vertical = 10.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(dev.name, fontSize = 15.sp)
                                Text(dev.address, fontSize = 11.sp, color = TextMuted)
                            }
                            Text(
                                text = if (connected) stringResource(R.string.bt_disconnect)
                                else stringResource(R.string.connect_button),
                                fontSize = 13.sp,
                                color = KeyIcon,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(stringResource(R.string.bt_note), fontSize = 12.sp, color = TextMuted, lineHeight = 17.sp)

                Spacer(Modifier.height(16.dp))
                Text(stringResource(R.string.bt_log_title), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                if (bt.log.isEmpty()) {
                    Text(stringResource(R.string.bt_log_empty), fontSize = 12.sp, color = TextMuted)
                } else {
                    bt.log.takeLast(14).forEach { line ->
                        Text(line, fontSize = 11.sp, color = TextMuted, lineHeight = 15.sp)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // Wi-Fi (ҳозирча ишламайди)
            MethodCard(
                icon = Icons.Default.Wifi,
                title = stringResource(R.string.wifi_title),
                badge = stringResource(R.string.badge_unavailable),
                description = stringResource(R.string.wifi_desc)
            ) {
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = onOpenWifiCheck) {
                    Text(stringResource(R.string.wifi_check_button), fontSize = 13.sp)
                }
            }

            Spacer(Modifier.height(12.dp))

            // ИК (Power)
            MethodCard(
                icon = Icons.Default.SettingsRemote,
                title = stringResource(R.string.ir_title),
                badge = stringResource(R.string.badge_experimental),
                description = stringResource(R.string.ir_desc)
            ) {
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = onOpenIr) {
                    Text(stringResource(R.string.ir_button), fontSize = 13.sp)
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onOpenIrLearn) {
                    Text(stringResource(R.string.ir_learn_button), fontSize = 13.sp)
                }
            }

            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) {
                Text(stringResource(R.string.sheet_close))
            }
        }
    }
}

@Composable
private fun MethodCard(
    icon: ImageVector,
    title: String,
    badge: String,
    description: String,
    extra: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Color(0xFF1F1F1F))
            .border(1.dp, KeyBorder, shape)
            .padding(16.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier.size(44.dp).clip(CircleShape).background(KeyFace),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = KeyIcon, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.width(10.dp))
                Text(
                    text = badge,
                    fontSize = 11.sp,
                    color = TextMuted,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color(0xFF2A2A2A))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(description, fontSize = 13.sp, color = TextMuted, lineHeight = 18.sp)
            extra()
        }
    }
}
