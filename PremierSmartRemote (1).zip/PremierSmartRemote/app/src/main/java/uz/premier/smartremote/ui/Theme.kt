package uz.premier.smartremote.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Қора ва тўқ кулранг палитра
val AppBackground = Color(0xFF0B0B0B)
val BodyTop = Color(0xFF202020)
val BodyBottom = Color(0xFF0F0F0F)
val BodyBorder = Color(0xFF2A2A2A)
val PanelTop = Color(0xFF292929)
val PanelBottom = Color(0xFF181818)
val PanelBorder = Color(0xFF353535)
val KeyFace = Color(0xFF2B2B2B)
val KeyFaceDark = Color(0xFF151515)
val KeyBorder = Color(0xFF3A3A3A)
val KeyIcon = Color(0xFFE9E9E9)
val TextMuted = Color(0xFF8C8C8C)
val PowerRed = Color(0xFFE53935)
val PillFace = Color(0xFFEDE8E1)
val PillText = Color(0xFF1E1E1E)
val StatusIdle = Color(0xFF8C8C8C)

private val Scheme = darkColorScheme(
    background = AppBackground,
    surface = Color(0xFF161616),
    onSurface = Color(0xFFEDEDED),
    onBackground = Color(0xFFEDEDED),
    primary = Color(0xFFEDEDED),
    onPrimary = Color(0xFF111111)
)

@Composable
fun PremierTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
