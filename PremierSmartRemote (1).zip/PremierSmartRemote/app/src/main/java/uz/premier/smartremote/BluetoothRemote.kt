package uz.premier.smartremote

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.concurrent.Executors

/**
 * Телефон телевизорга Bluetooth клавиатура/пульт (HID) бўлиб уланади.
 * ДИҚҚАТ: бу код ҳали ҳеч қандай телевизорда синалмаган.
 */
@SuppressLint("MissingPermission")
class BluetoothRemote(context: Context) {

    enum class State { IDLE, STARTING, READY, CONNECTING, CONNECTED, UNSUPPORTED }
    enum class Result { SENT, NOT_CONNECTED, UNSUPPORTED_KEY }

    data class Bonded(val name: String, val address: String)

    private val appContext = context.applicationContext
    private val adapter: BluetoothAdapter? =
        (appContext.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    private var hid: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null

    var state by mutableStateOf(State.IDLE)
        private set
    var hostName by mutableStateOf<String?>(null)
        private set
    var bonded by mutableStateOf<List<Bonded>>(emptyList())
        private set

    // Report 1 = Consumer Control (овоз, home, back...), Report 2 = клавиатура (стрелкалар, Enter, Esc)
    private val descriptor = intArrayOf(
        0x05, 0x0C, 0x09, 0x01, 0xA1, 0x01, 0x85, 0x01,
        0x15, 0x00, 0x26, 0xFF, 0x03, 0x19, 0x00, 0x2A, 0xFF, 0x03,
        0x75, 0x10, 0x95, 0x01, 0x81, 0x00, 0xC0,

        0x05, 0x01, 0x09, 0x06, 0xA1, 0x01, 0x85, 0x02,
        0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7, 0x15, 0x00, 0x25, 0x01,
        0x75, 0x01, 0x95, 0x08, 0x81, 0x02,
        0x95, 0x01, 0x75, 0x08, 0x81, 0x01,
        0x95, 0x06, 0x75, 0x08, 0x15, 0x00, 0x25, 0x65, 0x05, 0x07,
        0x19, 0x00, 0x29, 0x65, 0x81, 0x00, 0xC0
    ).map { it.toByte() }.toByteArray()

    private val consumer = mapOf(
        RemoteKey.POWER to 0x0030, RemoteKey.MUTE to 0x00E2,
        RemoteKey.VOL_UP to 0x00E9, RemoteKey.VOL_DOWN to 0x00EA,
        RemoteKey.MENU to 0x0040, RemoteKey.HOME to 0x0223, RemoteKey.BACK to 0x0224
    )
    private val keyboard = mapOf(
        RemoteKey.UP to 0x52, RemoteKey.DOWN to 0x51,
        RemoteKey.LEFT to 0x50, RemoteKey.RIGHT to 0x4F,
        RemoteKey.OK to 0x28, RemoteKey.EXIT to 0x29
    )

    val isSupported: Boolean get() = adapter != null

    /** BLUETOOTH_CONNECT рухсати берилгандан кейин чақирилади. */
    fun start() {
        val a = adapter
        if (a == null) { state = State.UNSUPPORTED; return }
        refreshBonded()
        if (hid != null) return
        state = State.STARTING
        val ok = a.getProfileProxy(appContext, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                val h = proxy as BluetoothHidDevice
                hid = h
                val sdp = BluetoothHidDeviceAppSdpSettings(
                    "PREMIER Smart Remote", "Телефон пулти", "PREMIER",
                    BluetoothHidDevice.SUBCLASS1_COMBO, descriptor
                )
                h.registerApp(sdp, null, null, executor, object : BluetoothHidDevice.Callback() {
                    override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
                        main.post { if (registered && state == State.STARTING) state = State.READY }
                    }

                    override fun onConnectionStateChanged(device: BluetoothDevice, connState: Int) {
                        main.post {
                            when (connState) {
                                BluetoothProfile.STATE_CONNECTED -> {
                                    host = device
                                    hostName = device.name ?: device.address
                                    state = State.CONNECTED
                                }
                                BluetoothProfile.STATE_CONNECTING -> state = State.CONNECTING
                                else -> {
                                    if (host?.address == device.address || host == null) {
                                        host = null
                                        hostName = null
                                        state = State.READY
                                    }
                                }
                            }
                        }
                    }
                })
            }

            override fun onServiceDisconnected(profile: Int) {
                hid = null; host = null; hostName = null
                main.post { state = State.IDLE }
            }
        }, BluetoothProfile.HID_DEVICE)
        if (!ok) state = State.UNSUPPORTED
    }

    fun refreshBonded() {
        bonded = adapter?.bondedDevices.orEmpty()
            .map { Bonded(it.name ?: it.address, it.address) }
            .sortedBy { it.name.lowercase() }
    }

    fun connect(address: String) {
        val h = hid ?: return
        val dev = adapter?.bondedDevices?.firstOrNull { it.address == address } ?: return
        state = State.CONNECTING
        if (!h.connect(dev)) state = State.READY
    }

    fun disconnect() {
        val h = hid ?: return
        host?.let { h.disconnect(it) }
    }

    fun stop() {
        try {
            hid?.unregisterApp()
            adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, hid)
        } catch (_: Exception) {
        }
        hid = null; host = null; hostName = null
        state = State.IDLE
    }

    fun press(key: RemoteKey): Result {
        val h = hid
        val d = host
        val usageC = consumer[key]
        val usageK = keyboard[key]
        if (usageC == null && usageK == null) return Result.UNSUPPORTED_KEY
        if (h == null || d == null || state != State.CONNECTED) return Result.NOT_CONNECTED

        if (usageC != null) {
            h.sendReport(d, 1, byteArrayOf((usageC and 0xFF).toByte(), (usageC shr 8).toByte()))
            main.postDelayed({ h.sendReport(d, 1, byteArrayOf(0, 0)) }, 40)
        } else if (usageK != null) {
            h.sendReport(d, 2, byteArrayOf(0, 0, usageK.toByte(), 0, 0, 0, 0, 0))
            main.postDelayed({ h.sendReport(d, 2, ByteArray(8)) }, 40)
        }
        return Result.SENT
    }
}
