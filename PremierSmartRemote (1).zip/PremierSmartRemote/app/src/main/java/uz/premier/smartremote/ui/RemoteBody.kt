package uz.premier.smartremote.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.premier.smartremote.R
import uz.premier.smartremote.RemoteKey

/**
 * Пулт корпуси. Барча ўлчамлар [width] га пропорционал, шунинг учун
 * ҳар хил телефон экранига мослашади.
 */
@Composable
fun RemoteBody(width: Dp, onKey: (RemoteKey) -> Unit) {
    val k = width.value / 320f
    fun d(x: Float): Dp = (x * k).dp

    val bodyShape = RoundedCornerShape(d(40f))
    val panelShape = RoundedCornerShape(d(30f))

    Column(
        modifier = Modifier
            .width(width)
            .clip(bodyShape)
            .background(Brush.verticalGradient(listOf(BodyTop, BodyBottom)))
            .border(1.dp, BodyBorder, bodyShape)
            .padding(horizontal = d(16f), vertical = d(18f)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // ── Юқори панель (тўқ кулранг, "чизилган" металл ўхшаш) ──
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(panelShape)
                .background(Brush.verticalGradient(listOf(PanelTop, PanelBottom)))
                .border(1.dp, PanelBorder, panelShape)
                .padding(d(14f)),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Power (марказда), Меню ва Овозсиз (икки ёнда, пастроқда)
            Box(Modifier.fillMaxWidth().height(d(84f))) {
                KeyButton(
                    onClick = { onKey(RemoteKey.POWER) },
                    desc = stringResource(R.string.key_power),
                    modifier = Modifier.align(Alignment.TopCenter).size(d(60f)),
                    background = SolidColor(PowerRed),
                    bordered = false
                ) { KeyIconView(Icons.Default.PowerSettingsNew, d(28f)) }

                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = d(30f)),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    KeyButton(
                        onClick = { onKey(RemoteKey.MENU) },
                        desc = stringResource(R.string.key_menu),
                        modifier = Modifier.size(d(54f))
                    ) { KeyIconView(Icons.Default.Menu, d(26f)) }
                    KeyButton(
                        onClick = { onKey(RemoteKey.MUTE) },
                        desc = stringResource(R.string.key_mute),
                        modifier = Modifier.size(d(54f))
                    ) { KeyIconView(Icons.AutoMirrored.Filled.VolumeOff, d(26f)) }
                }
            }

            Spacer(Modifier.height(d(12f)))
            DPad(size = d(236f), k = k, onKey = onKey)
            Spacer(Modifier.height(d(14f)))

            // Чиқиш / Орқага / Бош саҳифа / Air Mouse
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                KeyButton(
                    onClick = { onKey(RemoteKey.EXIT) },
                    desc = stringResource(R.string.key_exit),
                    modifier = Modifier.size(d(54f))
                ) {
                    Text(
                        stringResource(R.string.label_exit),
                        color = KeyIcon,
                        fontSize = (11f * k).sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                KeyButton(
                    onClick = { onKey(RemoteKey.BACK) },
                    desc = stringResource(R.string.key_back),
                    modifier = Modifier.size(d(54f))
                ) { KeyIconView(Icons.AutoMirrored.Filled.ArrowBack, d(26f)) }
                KeyButton(
                    onClick = { onKey(RemoteKey.HOME) },
                    desc = stringResource(R.string.key_home),
                    modifier = Modifier.size(d(54f))
                ) { KeyIconView(Icons.Default.Home, d(26f)) }
                KeyButton(
                    onClick = { onKey(RemoteKey.AIR_MOUSE) },
                    desc = stringResource(R.string.key_air_mouse),
                    modifier = Modifier.size(d(54f))
                ) { KeyIconView(Icons.Default.Mouse, d(26f)) }
            }

            Spacer(Modifier.height(d(14f)))

            // Илова тугмалари — оддий матн (бренд логотипларисиз)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(d(10f))) {
                PillKey("Netflix", "Netflix", k, Modifier.weight(1f)) { onKey(RemoteKey.NETFLIX) }
                PillKey("YouTube", "YouTube", k, Modifier.weight(1f)) { onKey(RemoteKey.YOUTUBE) }
            }
            Spacer(Modifier.height(d(10f)))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(d(10f))) {
                PillKey(
                    stringResource(R.string.label_source),
                    stringResource(R.string.key_source),
                    k,
                    Modifier.weight(1f)
                ) { onKey(RemoteKey.SOURCE) }
                PillKey("ITV", "ITV", k, Modifier.weight(1f)) { onKey(RemoteKey.ITV) }
            }
        }

        Spacer(Modifier.height(d(16f)))

        // ── Овоз: − / микрофон / + ──
        val pill = RoundedCornerShape(50)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(d(62f))
                .clip(pill)
                .background(Brush.verticalGradient(listOf(Color(0xFF262626), Color(0xFF1A1A1A))))
                .border(1.dp, KeyBorder, pill),
            verticalAlignment = Alignment.CenterVertically
        ) {
            KeyButton(
                onClick = { onKey(RemoteKey.VOL_DOWN) },
                desc = stringResource(R.string.key_vol_down),
                modifier = Modifier.weight(1f).height(d(62f)),
                shape = pill,
                background = SolidColor(Color.Transparent),
                bordered = false
            ) { KeyIconView(Icons.Default.Remove, d(28f)) }
            KeyButton(
                onClick = { onKey(RemoteKey.VOICE) },
                desc = stringResource(R.string.key_voice),
                modifier = Modifier.width(d(92f)).height(d(54f)),
                shape = pill,
                background = SolidColor(KeyFace)
            ) { KeyIconView(Icons.Default.Mic, d(28f)) }
            KeyButton(
                onClick = { onKey(RemoteKey.VOL_UP) },
                desc = stringResource(R.string.key_vol_up),
                modifier = Modifier.weight(1f).height(d(62f)),
                shape = pill,
                background = SolidColor(Color.Transparent),
                bordered = false
            ) { KeyIconView(Icons.Default.Add, d(28f)) }
        }

        Spacer(Modifier.height(d(26f)))
        Text(
            text = "PREMIER",
            color = Color(0xFFBDBDBD),
            fontSize = (20f * k).sp,
            fontWeight = FontWeight.Black,
            letterSpacing = (3f * k).sp
        )
        Spacer(Modifier.height(d(6f)))
    }
}

@Composable
private fun DPad(size: Dp, k: Float, onKey: (RemoteKey) -> Unit) {
    fun d(x: Float): Dp = (x * k).dp
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(Brush.radialGradient(listOf(Color(0xFF303030), Color(0xFF1B1B1B))))
            .border(1.dp, KeyBorder, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        KeyButton(
            onClick = { onKey(RemoteKey.UP) },
            desc = stringResource(R.string.key_up),
            modifier = Modifier.align(Alignment.TopCenter).padding(top = d(6f)).size(d(56f)),
            background = SolidColor(Color.Transparent),
            bordered = false
        ) { KeyIconView(Icons.Default.KeyboardArrowUp, d(34f), tint = Color(0xFFBDBDBD)) }
        KeyButton(
            onClick = { onKey(RemoteKey.DOWN) },
            desc = stringResource(R.string.key_down),
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = d(6f)).size(d(56f)),
            background = SolidColor(Color.Transparent),
            bordered = false
        ) { KeyIconView(Icons.Default.KeyboardArrowDown, d(34f), tint = Color(0xFFBDBDBD)) }
        KeyButton(
            onClick = { onKey(RemoteKey.LEFT) },
            desc = stringResource(R.string.key_left),
            modifier = Modifier.align(Alignment.CenterStart).padding(start = d(6f)).size(d(56f)),
            background = SolidColor(Color.Transparent),
            bordered = false
        ) { KeyIconView(Icons.AutoMirrored.Filled.KeyboardArrowLeft, d(34f), tint = Color(0xFFBDBDBD)) }
        KeyButton(
            onClick = { onKey(RemoteKey.RIGHT) },
            desc = stringResource(R.string.key_right),
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = d(6f)).size(d(56f)),
            background = SolidColor(Color.Transparent),
            bordered = false
        ) { KeyIconView(Icons.AutoMirrored.Filled.KeyboardArrowRight, d(34f), tint = Color(0xFFBDBDBD)) }

        KeyButton(
            onClick = { onKey(RemoteKey.OK) },
            desc = stringResource(R.string.key_ok),
            modifier = Modifier.size(d(98f)),
            background = SolidColor(KeyFaceDark)
        ) {
            Text(
                text = "OK",
                color = KeyIcon,
                fontSize = (24f * k).sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun PillKey(
    label: String,
    desc: String,
    k: Float,
    modifier: Modifier,
    onClick: () -> Unit
) {
    KeyButton(
        onClick = onClick,
        desc = desc,
        modifier = modifier.height((46f * k).dp),
        shape = RoundedCornerShape(50),
        background = SolidColor(PillFace),
        bordered = false
    ) {
        Text(
            text = label,
            color = PillText,
            fontSize = (14f * k).sp,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1
        )
    }
}

@Composable
private fun KeyIconView(icon: ImageVector, size: Dp, tint: Color = KeyIcon) {
    Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(size))
}
