package uz.premier.smartremote.ui

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import uz.premier.smartremote.BluetoothRemote
import uz.premier.smartremote.IrRemote
import uz.premier.smartremote.R
import uz.premier.smartremote.RemoteKey

@Composable
fun RemoteApp() {
    val ctx = LocalContext.current
    val bt = remember { BluetoothRemote(ctx) }
    val ir = remember { IrRemote(ctx) }
    DisposableEffect(Unit) { onDispose { bt.stop() } }

    var showSheet by remember { mutableStateOf(false) }
    var showIr by remember { mutableStateOf(false) }
    var showWifi by remember { mutableStateOf(false) }

    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current

    val msgNotConnected = stringResource(R.string.msg_not_connected)
    val msgUnsupported = stringResource(R.string.msg_key_unsupported)
    val msgDenied = stringResource(R.string.msg_permission_denied)

    fun toast(text: String) {
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            snackbar.showSnackbar(message = text, duration = SnackbarDuration.Short)
        }
    }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) bt.start() else toast(msgDenied)
    }

    fun startBluetooth() {
        val needsPermission = Build.VERSION.SDK_INT >= 31 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) !=
            PackageManager.PERMISSION_GRANTED
        if (needsPermission) permission.launch(Manifest.permission.BLUETOOTH_CONNECT) else bt.start()
    }

    val onKey: (RemoteKey) -> Unit = onKey@{ key ->
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        // Power: код топилган бўлса ИК орқали (ТВ ўчиқ бўлганда ҳам ишлайди)
        if (key == RemoteKey.POWER && ir.available && ir.hasSaved && ir.sendPower()) return@onKey
        when (bt.press(key)) {
            BluetoothRemote.Result.SENT -> Unit
            BluetoothRemote.Result.NOT_CONNECTED -> toast(msgNotConnected)
            BluetoothRemote.Result.UNSUPPORTED_KEY -> toast(msgUnsupported)
        }
    }

    val statusText = when (bt.state) {
        BluetoothRemote.State.IDLE -> stringResource(R.string.status_not_connected)
        BluetoothRemote.State.STARTING, BluetoothRemote.State.READY ->
            stringResource(R.string.status_bt_ready)
        BluetoothRemote.State.CONNECTING -> stringResource(R.string.status_bt_connecting)
        BluetoothRemote.State.CONNECTED ->
            stringResource(R.string.status_bt_connected, bt.hostName ?: "")
        BluetoothRemote.State.UNSUPPORTED -> stringResource(R.string.status_bt_unsupported)
    }
    val dot = if (bt.state == BluetoothRemote.State.CONNECTED) Color(0xFF4CAF50) else StatusIdle

    Scaffold(
        containerColor = AppBackground,
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Header(statusText = statusText, dot = dot, onConnect = {
                startBluetooth()
                bt.refreshBonded()
                showSheet = true
            })

            BoxWithConstraints(Modifier.fillMaxWidth().weight(1f)) {
                val fitByHeight: Dp = (maxHeight - 16.dp) / 2.2f
                val bodyWidth = minOf(maxWidth - 32.dp, fitByHeight, 340.dp).coerceAtLeast(250.dp)
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    RemoteBody(width = bodyWidth, onKey = onKey)
                }
            }
        }
    }

    if (showIr) IrFinderSheet(ir) { showIr = false }
    if (showWifi) WifiCheckSheet { showWifi = false }

    if (showSheet) {
        ConnectionSheet(
            bt = bt,
            onStartBluetooth = { startBluetooth() },
            onMakeVisible = {
                val i = Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                    .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120)
                try { ctx.startActivity(i) } catch (_: Exception) { }
            },
            onOpenBtSettings = {
                try { ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) } catch (_: Exception) { }
            },
            onOpenIr = { showSheet = false; showIr = true },
            onOpenWifiCheck = { showSheet = false; showWifi = true },
            onDismiss = { showSheet = false }
        )
    }
}

@Composable
private fun Header(statusText: String, dot: Color, onConnect: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "PREMIER", color = Color(0xFFF2F2F2), fontSize = 20.sp,
                    fontWeight = FontWeight.Black, letterSpacing = 3.sp
                )
                Text(
                    "SMART REMOTE", color = TextMuted, fontSize = 11.sp,
                    fontWeight = FontWeight.Medium, letterSpacing = 4.sp
                )
            }
            Button(
                onClick = onConnect,
                colors = ButtonDefaults.buttonColors(containerColor = KeyFace, contentColor = KeyIcon),
                shape = RoundedCornerShape(50)
            ) {
                Icon(Icons.Default.Bluetooth, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.connect_button), fontWeight = FontWeight.SemiBold)
            }
        }

        Spacer(Modifier.size(10.dp))

        val chip = RoundedCornerShape(50)
        Row(
            modifier = Modifier
                .clip(chip)
                .background(Color(0xFF181818))
                .border(1.dp, KeyBorder, chip)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Spacer(Modifier.size(8.dp).clip(CircleShape).background(dot))
            Spacer(Modifier.width(8.dp))
            Text(statusText, color = TextMuted, fontSize = 12.sp)
        }
    }
}
