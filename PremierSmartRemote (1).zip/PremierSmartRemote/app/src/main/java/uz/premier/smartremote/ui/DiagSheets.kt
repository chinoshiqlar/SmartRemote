package uz.premier.smartremote.ui

import android.content.Context
import android.net.ConnectivityManager
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uz.premier.smartremote.IrRemote
import uz.premier.smartremote.R
import uz.premier.smartremote.RemoteKey
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.Socket

private enum class IrMode { IDLE, SWEEP, REFINE }

private fun hex(v: Int) = "0x" + v.toString(16).uppercase().padStart(2, '0')

/** ИК кодни излаш: ТВ жавоб бергунча буйруқларни кетма-кет юборади. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IrFinderSheet(ir: IrRemote, onDismiss: () -> Unit) {
    var mode by remember { mutableStateOf(IrMode.IDLE) }
    var addrIdx by remember { mutableIntStateOf(0) }
    var cmd by remember { mutableIntStateOf(0) }
    var refine by remember { mutableStateOf<List<Pair<Int, Int>>>(emptyList()) }
    var refineIdx by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("") }

    val addrs = IrRemote.CANDIDATE_ADDRESSES
    val msgDone = stringResource(R.string.ir_done_nothing)
    val msgSaved = stringResource(R.string.ir_saved)

    LaunchedEffect(mode) {
        if (mode == IrMode.SWEEP) {
            while (isActive && mode == IrMode.SWEEP && addrIdx < addrs.size) {
                ir.send(addrs[addrIdx], cmd)
                delay(300)
                cmd++
                if (cmd > 255) { cmd = 0; addrIdx++ }
            }
            if (mode == IrMode.SWEEP) { mode = IrMode.IDLE; message = msgDone }
        } else if (mode == IrMode.REFINE) {
            while (isActive && mode == IrMode.REFINE && refineIdx < refine.size) {
                val (a, c) = refine[refineIdx]
                ir.send(a, c)
                delay(2200)
                if (mode == IrMode.REFINE) refineIdx++
            }
            if (mode == IrMode.REFINE) { mode = IrMode.IDLE; message = msgDone }
        }
    }

    ModalBottomSheet(
        onDismissRequest = { mode = IrMode.IDLE; onDismiss() },
        containerColor = Color(0xFF161616),
        contentColor = Color(0xFFEDEDED)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 20.dp)
        ) {
            Text(stringResource(R.string.ir_title), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(
                stringResource(
                    if (ir.available) R.string.ir_available else R.string.ir_unavailable
                ),
                fontSize = 14.sp, color = TextMuted
            )
            Spacer(Modifier.height(12.dp))
            Text(stringResource(R.string.ir_howto), fontSize = 13.sp, color = TextMuted, lineHeight = 18.sp)
            Spacer(Modifier.height(16.dp))

            if (ir.hasSaved) {
                Text(
                    stringResource(R.string.ir_current, hex(ir.address), hex(ir.command)),
                    fontSize = 14.sp, fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { ir.sendPower() },
                        colors = ButtonDefaults.buttonColors(containerColor = KeyFace, contentColor = KeyIcon)
                    ) { Text(stringResource(R.string.ir_test)) }
                    OutlinedButton(onClick = { ir.clear() }) { Text(stringResource(R.string.ir_clear)) }
                }
                Spacer(Modifier.height(16.dp))
            }

            when (mode) {
                IrMode.IDLE -> {
                    Button(
                        enabled = ir.available,
                        onClick = {
                            addrIdx = 0; cmd = 0; message = ""
                            mode = IrMode.SWEEP
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = KeyFace, contentColor = KeyIcon)
                    ) { Text(stringResource(R.string.ir_start)) }
                    if (ir.available && ir.hasSaved && addrs.contains(ir.address)) {
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = {
                                addrIdx = addrs.indexOf(ir.address); cmd = 0; message = ""
                                mode = IrMode.SWEEP
                            }
                        ) { Text(stringResource(R.string.ir_start_saved)) }
                    }
                }
                IrMode.SWEEP -> {
                    Text(
                        stringResource(R.string.ir_trying, hex(addrs[addrIdx.coerceAtMost(addrs.size - 1)]), hex(cmd)),
                        fontSize = 15.sp, fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                // ТВ жавоб берди: охирги юборилган буйруқлар орасидан аниқ топамиз
                                val list = ArrayList<Pair<Int, Int>>()
                                for (k in 1..15) {
                                    var c = cmd - k
                                    var a = addrIdx
                                    if (c < 0) { c += 256; a -= 1 }
                                    if (a >= 0) list.add(addrs[a] to c)
                                }
                                refine = list
                                refineIdx = 0
                                mode = IrMode.REFINE
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PowerRed, contentColor = Color.White)
                        ) { Text(stringResource(R.string.ir_found)) }
                        OutlinedButton(onClick = { mode = IrMode.IDLE }) {
                            Text(stringResource(R.string.ir_stop))
                        }
                    }
                }
                IrMode.REFINE -> {
                    val cur = refine.getOrNull(refineIdx.coerceAtMost((refine.size - 1).coerceAtLeast(0)))
                    Text(stringResource(R.string.ir_refine), fontSize = 13.sp, color = TextMuted, lineHeight = 18.sp)
                    Spacer(Modifier.height(8.dp))
                    if (cur != null) {
                        Text(
                            stringResource(R.string.ir_trying, hex(cur.first), hex(cur.second)),
                            fontSize = 15.sp, fontWeight = FontWeight.SemiBold
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                if (cur != null) {
                                    ir.save(cur.first, cur.second)
                                    message = msgSaved
                                }
                                mode = IrMode.IDLE
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PowerRed, contentColor = Color.White)
                        ) { Text(stringResource(R.string.ir_this_one)) }
                        OutlinedButton(onClick = { mode = IrMode.IDLE }) {
                            Text(stringResource(R.string.ir_stop))
                        }
                    }
                }
            }

            if (message.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text(message, fontSize = 13.sp, color = TextMuted, lineHeight = 18.sp)
            }
        }
    }
}

/** Wi-Fi тармоғида Android TV Remote хизмати (6466/6467 портлар) бор-йўқлигини текширади. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WifiCheckSheet(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var localIp by remember { mutableStateOf<String?>(null) }
    var found by remember { mutableStateOf<List<String>?>(null) }
    val noWifi = stringResource(R.string.wifi_check_no_network)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF161616),
        contentColor = Color(0xFFEDEDED)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 20.dp)
        ) {
            Text(stringResource(R.string.wifi_check_title), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(stringResource(R.string.wifi_check_desc), fontSize = 13.sp, color = TextMuted, lineHeight = 18.sp)
            Spacer(Modifier.height(16.dp))
            Button(
                enabled = !busy,
                onClick = {
                    busy = true
                    found = null
                    scope.launch {
                        val ip = localIpv4(ctx)
                        localIp = ip
                        found = if (ip == null) emptyList() else scanSubnet(ip)
                        busy = false
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = KeyFace, contentColor = KeyIcon)
            ) {
                Text(stringResource(if (busy) R.string.wifi_check_busy else R.string.wifi_check_start))
            }

            Spacer(Modifier.height(16.dp))
            if (!busy && found != null) {
                if (localIp == null) {
                    Text(noWifi, fontSize = 13.sp, color = TextMuted)
                } else {
                    Text(stringResource(R.string.wifi_check_my_ip, localIp ?: ""), fontSize = 12.sp, color = TextMuted)
                    Spacer(Modifier.height(8.dp))
                    val list = found.orEmpty()
                    if (list.isEmpty()) {
                        Text(stringResource(R.string.wifi_check_none), fontSize = 14.sp, lineHeight = 20.sp)
                    } else {
                        Text(stringResource(R.string.wifi_check_found), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        list.forEach { Text(it, fontSize = 14.sp) }
                    }
                }
            }
        }
    }
}

private fun localIpv4(ctx: Context): String? {
    return try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return null
        val lp = cm.getLinkProperties(net) ?: return null
        lp.linkAddresses.map { it.address }.filterIsInstance<Inet4Address>()
            .firstOrNull { !it.isLoopbackAddress }?.hostAddress
    } catch (_: Exception) {
        null
    }
}

private suspend fun scanSubnet(ip: String): List<String> = withContext(Dispatchers.IO) {
    val base = ip.substringBeforeLast('.')
    val ports = intArrayOf(6466, 6467)
    val hosts = (1..254).map { "$base.$it" }
    val out = ArrayList<String>()
    hosts.chunked(64).forEach { chunk ->
        val res = chunk.map { host ->
            async {
                val open = ports.filter { port ->
                    try {
                        Socket().use { s -> s.connect(InetSocketAddress(host, port), 400); true }
                    } catch (_: Exception) {
                        false
                    }
                }
                if (open.isEmpty()) null else "$host (порт: ${open.joinToString()})"
            }
        }.awaitAll()
        out.addAll(res.filterNotNull())
    }
    out
}


private enum class LearnMode { IDLE, SWEEP, REFINE, PICK }

private val LEARN_KEYS = listOf(
    RemoteKey.UP, RemoteKey.DOWN, RemoteKey.LEFT, RemoteKey.RIGHT, RemoteKey.OK,
    RemoteKey.BACK, RemoteKey.EXIT, RemoteKey.HOME, RemoteKey.MENU, RemoteKey.MUTE,
    RemoteKey.VOL_UP, RemoteKey.VOL_DOWN, RemoteKey.SOURCE,
    RemoteKey.NETFLIX, RemoteKey.YOUTUBE, RemoteKey.ITV
)

@Composable
private fun learnLabel(k: RemoteKey): String = when (k) {
    RemoteKey.UP -> stringResource(R.string.key_up)
    RemoteKey.DOWN -> stringResource(R.string.key_down)
    RemoteKey.LEFT -> stringResource(R.string.key_left)
    RemoteKey.RIGHT -> stringResource(R.string.key_right)
    RemoteKey.OK -> "OK"
    RemoteKey.BACK -> stringResource(R.string.key_back)
    RemoteKey.EXIT -> stringResource(R.string.key_exit)
    RemoteKey.HOME -> stringResource(R.string.key_home)
    RemoteKey.MENU -> stringResource(R.string.key_menu)
    RemoteKey.MUTE -> stringResource(R.string.key_mute)
    RemoteKey.VOL_UP -> stringResource(R.string.key_vol_up)
    RemoteKey.VOL_DOWN -> stringResource(R.string.key_vol_down)
    RemoteKey.SOURCE -> stringResource(R.string.key_source)
    RemoteKey.NETFLIX -> "Netflix"
    RemoteKey.YOUTUBE -> "YouTube"
    RemoteKey.ITV -> "ITV"
    else -> k.name
}

/**
 * Power манзилида барча буйруқларни кетма-кет юборади. ТВ экрани жавоб берганда,
 * фойдаланувчи бу қайси тугма эканини танлайди ва код шу тугмага сақланади.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun IrLearnSheet(ir: IrRemote, onDismiss: () -> Unit) {
    var mode by remember { mutableStateOf(LearnMode.IDLE) }
    var cmd by remember { mutableIntStateOf(0) }
    var refine by remember { mutableStateOf<List<Int>>(emptyList()) }
    var refineIdx by remember { mutableIntStateOf(0) }
    var picked by remember { mutableIntStateOf(-1) }
    var message by remember { mutableStateOf("") }
    val msgDone = stringResource(R.string.ir_learn_done)

    fun skip(c: Int) = c == ir.command || ir.learned.containsValue(c)

    LaunchedEffect(mode) {
        if (mode == LearnMode.SWEEP) {
            while (isActive && mode == LearnMode.SWEEP && cmd <= 255) {
                if (!skip(cmd)) {
                    ir.send(ir.address, cmd)
                    delay(280)
                }
                if (mode == LearnMode.SWEEP) cmd++
            }
            if (mode == LearnMode.SWEEP) { mode = LearnMode.IDLE; message = msgDone }
        } else if (mode == LearnMode.REFINE) {
            while (isActive && mode == LearnMode.REFINE && refineIdx < refine.size) {
                ir.send(ir.address, refine[refineIdx])
                delay(1600)
                if (mode == LearnMode.REFINE) refineIdx++
            }
            if (mode == LearnMode.REFINE) mode = LearnMode.SWEEP
        }
    }

    ModalBottomSheet(
        onDismissRequest = { mode = LearnMode.IDLE; onDismiss() },
        containerColor = Color(0xFF161616),
        contentColor = Color(0xFFEDEDED)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 20.dp)
        ) {
            Text(stringResource(R.string.ir_learn_title), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))

            if (!ir.hasSaved || !ir.available) {
                Text(stringResource(R.string.ir_learn_need_code), fontSize = 14.sp, color = TextMuted, lineHeight = 20.sp)
                return@Column
            }

            Text(stringResource(R.string.ir_learn_howto), fontSize = 13.sp, color = TextMuted, lineHeight = 18.sp)
            Spacer(Modifier.height(12.dp))
            Text(
                stringResource(R.string.ir_learn_count, ir.learned.size, LEARN_KEYS.size),
                fontSize = 14.sp, fontWeight = FontWeight.SemiBold
            )
            if (ir.learned.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    LEARN_KEYS.filter { ir.learned.containsKey(it.name) }
                        .map { learnLabel(it) }
                        .joinToString(", "),
                    fontSize = 12.sp, color = TextMuted
                )
            }
            Spacer(Modifier.height(16.dp))

            when (mode) {
                LearnMode.IDLE -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { cmd = if (cmd >= 255) 0 else cmd; message = ""; mode = LearnMode.SWEEP },
                            colors = ButtonDefaults.buttonColors(containerColor = KeyFace, contentColor = KeyIcon)
                        ) {
                            Text(stringResource(if (cmd > 0 && cmd < 255) R.string.ir_learn_resume else R.string.ir_start))
                        }
                        if (ir.learned.isNotEmpty()) {
                            OutlinedButton(onClick = { ir.clearKeys() }) {
                                Text(stringResource(R.string.ir_learn_clear))
                            }
                        }
                    }
                }
                LearnMode.SWEEP -> {
                    Text(
                        stringResource(R.string.ir_learn_progress, cmd.coerceAtMost(255), 255),
                        fontSize = 15.sp, fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                refine = (0..5).map { cmd - it }.filter { it >= 0 && !skip(it) }
                                refineIdx = 0
                                mode = LearnMode.REFINE
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PowerRed, contentColor = Color.White)
                        ) { Text(stringResource(R.string.ir_found)) }
                        OutlinedButton(onClick = { mode = LearnMode.IDLE }) {
                            Text(stringResource(R.string.ir_stop))
                        }
                    }
                }
                LearnMode.REFINE -> {
                    Text(stringResource(R.string.ir_refine), fontSize = 13.sp, color = TextMuted, lineHeight = 18.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                picked = refine.getOrNull(refineIdx.coerceAtMost((refine.size - 1).coerceAtLeast(0))) ?: -1
                                mode = if (picked >= 0) LearnMode.PICK else LearnMode.SWEEP
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PowerRed, contentColor = Color.White)
                        ) { Text(stringResource(R.string.ir_this_one)) }
                        OutlinedButton(onClick = { mode = LearnMode.SWEEP }) {
                            Text(stringResource(R.string.ir_learn_cancel))
                        }
                    }
                }
                LearnMode.PICK -> {
                    Text(stringResource(R.string.ir_learn_pick), fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(10.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LEARN_KEYS.forEach { k ->
                            val done = ir.learned.containsKey(k.name)
                            OutlinedButton(onClick = {
                                ir.saveKey(k, picked)
                                mode = LearnMode.SWEEP
                            }) { Text((if (done) "✓ " else "") + learnLabel(k), fontSize = 13.sp) }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = { mode = LearnMode.SWEEP }) {
                        Text(stringResource(R.string.ir_learn_cancel))
                    }
                }
            }

            if (message.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text(message, fontSize = 13.sp, color = TextMuted, lineHeight = 18.sp)
            }
        }
    }
}
