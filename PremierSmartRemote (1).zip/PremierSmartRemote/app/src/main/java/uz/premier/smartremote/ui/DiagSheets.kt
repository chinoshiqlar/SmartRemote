package uz.premier.smartremote.ui

import android.content.Context
import android.net.ConnectivityManager
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uz.premier.smartremote.IrRemote
import uz.premier.smartremote.R
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.Socket

private enum class IrMode { IDLE, SWEEP, REFINE }

private fun hex(v: Int) = "0x" + v.toString(16).uppercase().padStart(2, '0')

/** ИК кодни излаш: ТВ жавоб бергунча буйруқларни кетма-кет юборади. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IrFinderSheet(ir: IrRemote, onDismiss: () -> Unit) {
    var mode by remember { mutableStateOf(IrMode.IDLE) }
    var addrIdx by remember { mutableIntStateOf(0) }
    var cmd by remember { mutableIntStateOf(0) }
    var refine by remember { mutableStateOf<List<Pair<Int, Int>>>(emptyList()) }
    var refineIdx by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("") }

    val addrs = IrRemote.CANDIDATE_ADDRESSES
    val msgDone = stringResource(R.string.ir_done_nothing)
    val msgSaved = stringResource(R.string.ir_saved)

    LaunchedEffect(mode) {
        if (mode == IrMode.SWEEP) {
            while (isActive && mode == IrMode.SWEEP && addrIdx < addrs.size) {
                ir.send(addrs[addrIdx], cmd)
                delay(300)
                cmd++
                if (cmd > 255) { cmd = 0; addrIdx++ }
            }
            if (mode == IrMode.SWEEP) { mode = IrMode.IDLE; message = msgDone }
        } else if (mode == IrMode.REFINE) {
            while (isActive && mode == IrMode.REFINE && refineIdx < refine.size) {
                val (a, c) = refine[refineIdx]
                ir.send(a, c)
                delay(2200)
                if (mode == IrMode.REFINE) refineIdx++
            }
            if (mode == IrMode.REFINE) { mode = IrMode.IDLE; message = msgDone }
        }
    }

    ModalBottomSheet(
        onDismissRequest = { mode = IrMode.IDLE; onDismiss() },
        containerColor = Color(0xFF161616),
        contentColor = Color(0xFFEDEDED)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 20.dp)
        ) {
            Text(stringResource(R.string.ir_title), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(
                stringResource(
                    if (ir.available) R.string.ir_available else R.string.ir_unavailable
                ),
                fontSize = 14.sp, color = TextMuted
            )
            Spacer(Modifier.height(12.dp))
            Text(stringResource(R.string.ir_howto), fontSize = 13.sp, color = TextMuted, lineHeight = 18.sp)
            Spacer(Modifier.height(16.dp))

            if (ir.hasSaved) {
                Text(
                    stringResource(R.string.ir_current, hex(ir.address), hex(ir.command)),
                    fontSize = 14.sp, fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { ir.sendPower() },
                        colors = ButtonDefaults.buttonColors(containerColor = KeyFace, contentColor = KeyIcon)
                    ) { Text(stringResource(R.string.ir_test)) }
                    OutlinedButton(onClick = { ir.clear() }) { Text(stringResource(R.string.ir_clear)) }
                }
                Spacer(Modifier.height(16.dp))
            }

            when (mode) {
                IrMode.IDLE -> {
                    Button(
                        enabled = ir.available,
                        onClick = {
                            addrIdx = 0; cmd = 0; message = ""
                            mode = IrMode.SWEEP
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = KeyFace, contentColor = KeyIcon)
                    ) { Text(stringResource(R.string.ir_start)) }
                    if (ir.available && ir.hasSaved && addrs.contains(ir.address)) {
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = {
                                addrIdx = addrs.indexOf(ir.address); cmd = 0; message = ""
                                mode = IrMode.SWEEP
                            }
                        ) { Text(stringResource(R.string.ir_start_saved)) }
                    }
                }
                IrMode.SWEEP -> {
                    Text(
                        stringResource(R.string.ir_trying, hex(addrs[addrIdx.coerceAtMost(addrs.size - 1)]), hex(cmd)),
                        fontSize = 15.sp, fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                // ТВ жавоб берди: охирги юборилган буйруқлар орасидан аниқ топамиз
                                val list = ArrayList<Pair<Int, Int>>()
                                for (k in 1..15) {
                                    var c = cmd - k
                                    var a = addrIdx
                                    if (c < 0) { c += 256; a -= 1 }
                                    if (a >= 0) list.add(addrs[a] to c)
                                }
                                refine = list
                                refineIdx = 0
                                mode = IrMode.REFINE
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PowerRed, contentColor = Color.White)
                        ) { Text(stringResource(R.string.ir_found)) }
                        OutlinedButton(onClick = { mode = IrMode.IDLE }) {
                            Text(stringResource(R.string.ir_stop))
                        }
                    }
                }
                IrMode.REFINE -> {
                    val cur = refine.getOrNull(refineIdx.coerceAtMost((refine.size - 1).coerceAtLeast(0)))
                    Text(stringResource(R.string.ir_refine), fontSize = 13.sp, color = TextMuted, lineHeight = 18.sp)
                    Spacer(Modifier.height(8.dp))
                    if (cur != null) {
                        Text(
                            stringResource(R.string.ir_trying, hex(cur.first), hex(cur.second)),
                            fontSize = 15.sp, fontWeight = FontWeight.SemiBold
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                if (cur != null) {
                                    ir.save(cur.first, cur.second)
                                    message = msgSaved
                                }
                                mode = IrMode.IDLE
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PowerRed, contentColor = Color.White)
                        ) { Text(stringResource(R.string.ir_this_one)) }
                        OutlinedButton(onClick = { mode = IrMode.IDLE }) {
                            Text(stringResource(R.string.ir_stop))
                        }
                    }
                }
            }

            if (message.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text(message, fontSize = 13.sp, color = TextMuted, lineHeight = 18.sp)
            }
        }
    }
}

/** Wi-Fi тармоғида Android TV Remote хизмати (6466/6467 портлар) бор-йўқлигини текширади. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WifiCheckSheet(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var localIp by remember { mutableStateOf<String?>(null) }
    var found by remember { mutableStateOf<List<String>?>(null) }
    val noWifi = stringResource(R.string.wifi_check_no_network)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF161616),
        contentColor = Color(0xFFEDEDED)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 20.dp)
        ) {
            Text(stringResource(R.string.wifi_check_title), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(stringResource(R.string.wifi_check_desc), fontSize = 13.sp, color = TextMuted, lineHeight = 18.sp)
            Spacer(Modifier.height(16.dp))
            Button(
                enabled = !busy,
                onClick = {
                    busy = true
                    found = null
                    scope.launch {
                        val ip = localIpv4(ctx)
                        localIp = ip
                        found = if (ip == null) emptyList() else scanSubnet(ip)
                        busy = false
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = KeyFace, contentColor = KeyIcon)
            ) {
                Text(stringResource(if (busy) R.string.wifi_check_busy else R.string.wifi_check_start))
            }

            Spacer(Modifier.height(16.dp))
            if (!busy && found != null) {
                if (localIp == null) {
                    Text(noWifi, fontSize = 13.sp, color = TextMuted)
                } else {
                    Text(stringResource(R.string.wifi_check_my_ip, localIp ?: ""), fontSize = 12.sp, color = TextMuted)
                    Spacer(Modifier.height(8.dp))
                    val list = found.orEmpty()
                    if (list.isEmpty()) {
                        Text(stringResource(R.string.wifi_check_none), fontSize = 14.sp, lineHeight = 20.sp)
                    } else {
                        Text(stringResource(R.string.wifi_check_found), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        list.forEach { Text(it, fontSize = 14.sp) }
                    }
                }
            }
        }
    }
}

private fun localIpv4(ctx: Context): String? {
    return try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return null
        val lp = cm.getLinkProperties(net) ?: return null
        lp.linkAddresses.map { it.address }.filterIsInstance<Inet4Address>()
            .firstOrNull { !it.isLoopbackAddress }?.hostAddress
    } catch (_: Exception) {
        null
    }
}

private suspend fun scanSubnet(ip: String): List<String> = withContext(Dispatchers.IO) {
    val base = ip.substringBeforeLast('.')
    val ports = intArrayOf(6466, 6467)
    val hosts = (1..254).map { "$base.$it" }
    val out = ArrayList<String>()
    hosts.chunked(64).forEach { chunk ->
        val res = chunk.map { host ->
            async {
                val open = ports.filter { port ->
                    try {
                        Socket().use { s -> s.connect(InetSocketAddress(host, port), 400); true }
                    } catch (_: Exception) {
                        false
                    }
                }
                if (open.isEmpty()) null else "$host (порт: ${open.joinToString()})"
            }
        }.awaitAll()
        out.addAll(res.filterNotNull())
    }
    out
}
