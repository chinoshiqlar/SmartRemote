# PREMIER SMART REMOTE

Телевизор пульти иловаси (Android, Kotlin + Jetpack Compose).
**Босқич 1: фақат интерфейс.** Телевизор билан ҳақиқий алоқа ҳали йўқ.

## Ҳозирги ҳолат

| Нарса | Ҳолат |
|---|---|
| Ўзбекча интерфейс, қора/тўқ кулранг дизайн | Тайёр |
| Bluetooth (телефон = Bluetooth пулт) | Код ёзилган, **ҳали ҳеч қандай телевизорда синалмаган** |
| Bluetooth орқали юбориладиган тугмалар | Power, Меню, Овозсиз, Овоз −/+, Бош саҳифа, Орқага, Чиқиш, йўналишлар, OK (ишлаши тасдиқланмаган) |
| Netflix, YouTube, ITV, Манба, Микрофон, Air Mouse | Bluetooth орқали ишламайди (босилганда хабар чиқади) |
| Wi-Fi (Android TV Remote) | Ишламайди: телевизор Google TV иловасида топилмади |
| ИК | Амалга оширилмаган (`docs/draft_transports`, қоралама) |

Телефон Android 9 (API 28) ёки янги бўлиши керак.

## Ишга тушириш

1. Android Studio (Koala ёки янги) да `PremierSmartRemote` папкасини очинг.
2. Gradle синхронланишини кутинг (Android Studio керакли Gradle wrapper ни ўзи таклиф қилади).
3. Телефон ёки эмулятор танлаб **Run ▶** босинг.

## APK чиқариш

- Синов учун: **Build → Build APK(s)** → `app/build/outputs/apk/debug/app-debug.apk`
- Тарқатиш учун: **Build → Generate Signed Bundle / APK** (ўз калитингиз билан имзолаш керак).

Параметрлар: `applicationId = uz.premier.smartremote`, minSdk 26 (Android 8.0), targetSdk 34.

## Тузилма

```
app/src/main/java/uz/premier/smartremote/
├── MainActivity.kt          кириш нуқтаси
├── RemoteKey.kt             тугмалар рўйхати
├── BluetoothRemote.kt       Bluetooth HID пулт (синалмаган)
└── ui/
    ├── Theme.kt             ranglar
    ├── KeyButton.kt         умумий тугма (босилганда анимация)
    ├── RemoteBody.kt        пулт корпуси ва барча тугмалар
    ├── ConnectionSheet.kt   Wi-Fi / Bluetooth ойнаси
    └── RemoteApp.kt         асосий экран
app/src/main/res/values/strings.xml   барча ўзбекча матнлар
docs/draft_transports/       ИК / Bluetooth / Wi-Fi учун аввалги қоралама кодлар (ЛОЙИҲАГА УЛАНМАГАН, синалмаган)
```

## Эслатмалар

- Матнлар кирилл ёзувида. Лотин ёзувига ўтиш учун фақат `strings.xml` ни ўзгартириш кифоя.
- Netflix, YouTube ва ITV тугмалари оддий матн: уларнинг расмий логотиплари ишлатилмаган.
- `docs/draft_transports` ичидаги кодлар (ИК, Bluetooth HID, Wi-Fi жадвали) ҳали ҳеч қандай телевизорда
  синалмаган. Кейинги босқичда улаб, ҳар бирини текширамиз.

## GitHub орқали APK йиғиш (компьютерсиз)

`.github/workflows/build-apk.yml` файли мавжуд. Лойиҳани GitHub репозиторийсига юклагач,
**Actions** бўлимида "APK йиғиш" ишга тушади. Тайёр бўлгач, ишнинг саҳифасидан
`premier-smart-remote-apk` архивини юклаб олинг, ичида `app-debug.apk` бор.
